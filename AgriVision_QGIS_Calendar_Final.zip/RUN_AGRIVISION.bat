@echo off
cd /d "%~dp0"
echo Starting AgriVision from:
cd
if not exist "app.py" (
  echo ERROR: app.py is not in this folder.
  pause
  exit /b 1
)
if not exist "index.html" (
  echo ERROR: index.html is not in this folder.
  pause
  exit /b 1
)
if not exist "qgis_crop_calendar\june.png" (
  echo WARNING: qgis_crop_calendar images are missing.
  echo Copy the qgis_crop_calendar folder beside app.py.
)
python app.py
pause
