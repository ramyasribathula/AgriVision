AgriVision Crop Doctor model hook

Current version:
- Performs image-quality checks and visual triage.
- Ranks crop-specific possible issues from visible symptoms and optional symptom text.
- Provides IPM/organic-first guidance and confirmation-only treatment guidance.
- Does NOT claim a validated disease/pest diagnosis.

For true named image prediction, add an independently evaluated TorchScript model later:
models/crop_doctor_model.pt
models/classes.json

classes.json example:
["Rice___healthy", "Rice___blast", "Rice___brown_spot", "Rice___bacterial_leaf_blight", "Rice___stem_borer"]

The model must be trained/evaluated on representative field images, not only laboratory-style images.
